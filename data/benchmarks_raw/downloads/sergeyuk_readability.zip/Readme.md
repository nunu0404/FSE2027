This is replication package for the paper Reassessing Java Code Readability Models with a Human-Centered Approach.
In data folder one can find following datasets:
- snippets.csv: dataset with snippets and model scoring (note that the readability score in this table is 0 when readable and 1 when snippet is unreadable)
- raw_data.csv: dataset with raw human evaluation of snippets 
- aggregated.csv: aggregated human evaluation dataset
- snippets_with_human_scores.csv: dataset with snippets, model scoring and counted human scores

Also, replication package contains two notebooks with calculations
- one for descriptive analysis and another for reliability analysis